
public class Main  {

    private static int[][] BOARD = {
            {0, 0, 0, 7, 0, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 4, 3, 0, 2, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 6},
            {0, 0, 0, 5, 0, 9, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 4, 1, 8},
            {0, 0, 0, 0, 8, 1, 0, 0, 0},
            {0, 0, 2, 0, 0, 0, 0, 5, 0},
            {0, 4, 0, 0, 0, 0, 3, 0, 0},
    };

    public static void main(String[] args) {

        Board();


        if (Check()) {
            System.out.println(" VICTORY:");
            Board();
        } else {
            System.out.println("OOPS!");
        }

    }


    private static void Board(){
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(" " + BOARD[i][j]);
            }

            System.out.println();
        }
        System.out.println();
    }



   ///////////////////////////////////////////////////////////

    private static boolean CheckRow(int row, int number) {
        for (int i = 0; i < 9; i++)
            if (BOARD[row][i] == number)
                return true;

        return false;
    }

    private static boolean CheckCol(int col, int number) {
        for (int i = 0; i < 9; i++)
            if (BOARD[i][col] == number)
                return true;

        return false;
    }

    private static boolean CheckRowCol(int row, int col, int number) {
        int r = row - row % 3;
        int c = col - col % 3;

        for (int i = r; i < r + 3; i++)
            for (int j = c; j < c + 3; j++)
                if (BOARD[i][j] == number)
                    return true;

        return false;
    }


    //////////////////////////////////////////////////////////////////////////////////////




    private static boolean Check() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {

                if (BOARD[row][col] == 0) {

                    for (int number = 1; number <= 9; number++) {


                        if (!CheckRow(row, number) && !CheckCol(col, number) && !CheckRowCol(row, col, number)) {

                            BOARD[row][col] = number;

                            if (Check()) {

                                return true;

                            } else {

                                BOARD[row][col] = 0;
                            }
                        }
                    }

                    return false;
                }
            }
        }

        return true;
    }



}

